<?php

    require_once "header.php";

?>
            <div id="conteudoPage"></div>
            <script src="../public/js/gerenciarUsuarios.js"></script>
                    
        </section>
<?php

$ds = DIRECTORY_SEPARATOR;
require_once "..".$ds."public".$ds."view-components".$ds."footer.php";

?>