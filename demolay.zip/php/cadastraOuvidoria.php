<?php
if(isset($_POST["nome"])){
 
    
        $nome = trim(strip_tags($_POST["nome"]));
        $telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_NUMBER_INT);
        $cidade = trim(strip_tags($_POST["cidade"]));
        $comentario = trim(strip_tags($_POST["comentario"]));
        
        if(empty($nome)){
            header("location: ../ouvidoria/?sucess=false");
        }

    require "persistence.php";
    $stmt = new Persistence();

    $prestacaoConta = [
        1=>$nome,
        $telefone,
        $cidade,
        $comentario
    ];

        
    $query = "INSERT INTO `ouvidoria` (`nome`, `telefone`, `cidade`, `comentario`) VALUES (?, ?, ?, ?);";

    $res = $stmt->runQuery($query, $prestacaoConta);

    if(!$res){
        echo "<script>alert('Erro de inserção no banco!');</script><meta http-equiv='refresh' content='0; http:../ouvidoria/'>";
    }
    header("location: ../ouvidoria/?sucess=true");

}else{
$ds = DIRECTORY_SEPARATOR;
header("location: ..".$ds."public".$ds."view-components".$ds."page404.php"); 
}