<?php
    $ds = DIRECTORY_SEPARATOR;
    require_once "..".$ds."public".$ds."view-components".$ds."page404.php";
?>