<footer class="rodape">
            <div class="dados">
                <div>
                    Loja Moçonica&#8680;Deus e Amor. Crato-CE.
                </div>
                <div>
                    Bairro: Muriti, Avenida: Padre Cícero, Km: 4, Nº: 1109.
                </div>
                <div>
                    <i class="fa fa-facebook icos" title="Facebook"></i>
                    <i class="fa fa-instagram icos" title="Instagram"></i>     
                </div>
                <div>
                    <strong>Copyright &copy; <?php echo date("Y");?>.</strong> Todos os direitos reservados.
                    <strong>Dev &copy; Kainan Paiva.</strong> <span>Contatos&#8680; Email: kainan.paiva777@gmail.com, Tel: (88) 9 9262-5107</span>
                </div>
            </div>
    </footer>    
</div>
</body>
</html>