
document.addEventListener('keydown', function(e) {
    e = e || window.event;
    var code = e.which || e.keyCode;
    modal = document.getElementById('modal').style.display;

    if(code == 27 && modal == "block"){
        showDiv('modal');
    }       
});

function showDiv(identificador){
    var displ = document.getElementById(identificador).style.display;
    if(displ == "none" || displ == ""){
        document.getElementById(identificador).style.display = "block";
    }else{
        document.getElementById(identificador).style.display = "none";
    }
}