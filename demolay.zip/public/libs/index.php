<?php
$ds = DIRECTORY_SEPARATOR;
header ("location: ..".$ds."view-components".$ds."page404.php");
?>