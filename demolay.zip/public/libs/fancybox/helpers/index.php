<?php
header("location: ../../../../page404.php");
?>