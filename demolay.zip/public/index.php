<?php
$ds = DIRECTORY_SEPARATOR;
header("location: ..$ds");
?>